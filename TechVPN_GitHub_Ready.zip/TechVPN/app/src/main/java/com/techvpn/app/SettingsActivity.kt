package com.techvpn.app

import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.techvpn.app.databinding.ActivitySettingsBinding

class SettingsActivity : AppCompatActivity() {

    private lateinit var b: ActivitySettingsBinding
    private lateinit var store: ServerStore
    private lateinit var adapter: ServerAdapter
    private var pendingImport: Country? = null

    private val importPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val c = pendingImport
            pendingImport = null
            if (uri != null && c != null) {
                val err = ConfigImport.import(this, uri, c)
                if (err == null) {
                    Toast.makeText(this, "${c.name} server imported", Toast.LENGTH_SHORT).show()
                    refresh()
                } else {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Import failed")
                        .setMessage(err)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivitySettingsBinding.inflate(layoutInflater)
        setContentView(b.root)
        store = ServerStore.get(this)

        adapter = ServerAdapter(
            manage = true,
            onAction = { c ->
                pendingImport = c
                importPicker.launch(arrayOf("*/*"))
            },
            onRemove = ::confirmRemove,
            onSelect = {}
        )
        b.settingsList.layoutManager = LinearLayoutManager(this)
        b.settingsList.adapter = adapter
        b.settingsList.isNestedScrollingEnabled = false
        b.backButton.setOnClickListener { finish() }
        refresh()
    }

    private fun confirmRemove(c: Country) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Remove ${c.name}?")
            .setMessage("The saved configuration for ${c.flag} ${c.name} will be deleted from this device.")
            .setPositiveButton("Remove") { _, _ ->
                val st = VpnController.state.value
                val inUse = st.country?.code == c.code &&
                    (st.status == Status.CONNECTING || st.status == Status.CONNECTED)
                if (inUse) VpnController.disconnect(this)
                store.remove(c.code)
                refresh()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun refresh() {
        adapter.submit(
            Countries.all.map {
                ServerRow(it, store.has(it.code), active = false, connecting = false, selected = false)
            }
        )
    }
}
