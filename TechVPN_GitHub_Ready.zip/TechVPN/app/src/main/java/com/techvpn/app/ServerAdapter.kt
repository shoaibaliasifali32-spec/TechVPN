package com.techvpn.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.techvpn.app.databinding.ItemServerBinding

data class ServerRow(
    val country: Country,
    val configured: Boolean,
    val active: Boolean,
    val connecting: Boolean,
    val selected: Boolean
)

class ServerAdapter(
    private val manage: Boolean,
    private val onAction: (Country) -> Unit,
    private val onRemove: (Country) -> Unit,
    private val onSelect: (Country) -> Unit
) : RecyclerView.Adapter<ServerAdapter.VH>() {

    private var rows: List<ServerRow> = emptyList()

    fun submit(list: List<ServerRow>) {
        rows = list
        notifyDataSetChanged()
    }

    class VH(val b: ItemServerBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH =
        VH(ItemServerBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun getItemCount(): Int = rows.size

    override fun onBindViewHolder(holder: VH, position: Int) {
        val row = rows[position]
        val b = holder.b
        val ctx = b.root.context
        fun color(id: Int) = ContextCompat.getColor(ctx, id)

        b.tvFlag.text = row.country.flag
        b.tvName.text = row.country.name

        val (statusText, statusColor) = when {
            manage && row.configured -> "Configured" to R.color.green
            manage -> "Not configured" to R.color.text_secondary
            row.active && row.connecting -> "Connecting…" to R.color.amber
            row.active -> "Connected" to R.color.green
            row.configured -> "Ready" to R.color.cyan
            else -> "Server configuration required" to R.color.amber
        }
        b.tvStatus.text = statusText
        b.tvStatus.setTextColor(color(statusColor))

        b.btnAction.text = when {
            manage -> if (row.configured) "Replace" else "Import"
            row.active -> "Disconnect"
            row.configured -> "Connect"
            else -> "Import"
        }

        b.btnRemove.visibility =
            if (manage && row.configured) android.view.View.VISIBLE else android.view.View.GONE
        b.btnRemove.setOnClickListener { onRemove(row.country) }
        b.btnAction.setOnClickListener { onAction(row.country) }
        b.card.setOnClickListener { onSelect(row.country) }

        if (!manage && row.selected) {
            b.card.strokeColor = color(R.color.blue)
            b.card.strokeWidth = (2 * ctx.resources.displayMetrics.density).toInt()
        } else {
            b.card.strokeColor = color(R.color.navy_stroke)
            b.card.strokeWidth = (1 * ctx.resources.displayMetrics.density).toInt()
        }
    }
}
