package com.techvpn.app

import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.net.VpnService
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.graphics.ColorUtils
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.techvpn.app.databinding.ActivityMainBinding
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding
    private lateinit var store: ServerStore
    private lateinit var adapter: ServerAdapter

    private var selected: Country = Countries.all.first()
    private var pendingConnect: Country? = null
    private var pendingImport: Country? = null

    private val vpnPermission =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val c = pendingConnect
            pendingConnect = null
            if (c != null) {
                if (result.resultCode == RESULT_OK) {
                    VpnController.connect(this, c)
                } else {
                    VpnController.reportError(
                        c,
                        "VPN permission was denied. Tech VPN needs it to create the secure tunnel."
                    )
                }
            }
        }

    private val importPicker =
        registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
            val c = pendingImport
            pendingImport = null
            if (uri != null && c != null) {
                val err = ConfigImport.import(this, uri, c)
                if (err == null) {
                    Toast.makeText(this, "${c.name} server imported", Toast.LENGTH_SHORT).show()
                    select(c)
                } else {
                    MaterialAlertDialogBuilder(this)
                        .setTitle("Import failed")
                        .setMessage(err)
                        .setPositiveButton("OK", null)
                        .show()
                }
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        store = ServerStore.get(this)
        selected = Countries.byCode(store.selectedCode())
            ?: Countries.all.firstOrNull { store.has(it.code) }
            ?: Countries.all.first()

        adapter = ServerAdapter(
            manage = false,
            onAction = ::onServerAction,
            onRemove = {},
            onSelect = ::select
        )
        b.serverList.layoutManager = LinearLayoutManager(this)
        b.serverList.adapter = adapter
        b.serverList.isNestedScrollingEnabled = false

        b.settingsButton.setOnClickListener {
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        b.connectButton.setOnClickListener { onMainButton() }
        b.reconnectButton.setOnClickListener {
            val c = VpnController.state.value.country ?: selected
            if (store.has(c.code)) requestConnect(c) else promptImport(c)
        }

        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch { VpnController.state.collect { render(it) } }
                launch {
                    while (true) {
                        updateTimer(VpnController.state.value)
                        delay(1000)
                    }
                }
            }
        }
    }

    private fun select(c: Country) {
        selected = c
        store.setSelected(c.code)
        render(VpnController.state.value)
    }

    private fun onMainButton() {
        when (VpnController.state.value.status) {
            Status.CONNECTING, Status.CONNECTED -> VpnController.disconnect(this)
            else -> if (store.has(selected.code)) requestConnect(selected) else promptImport(selected)
        }
    }

    private fun onServerAction(c: Country) {
        val st = VpnController.state.value
        val active = st.country?.code == c.code &&
            (st.status == Status.CONNECTING || st.status == Status.CONNECTED)
        when {
            active -> VpnController.disconnect(this)
            !store.has(c.code) -> promptImport(c)
            else -> {
                select(c)
                requestConnect(c)
            }
        }
    }

    private fun promptImport(c: Country) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Server configuration required")
            .setMessage("Import a WireGuard .conf file for ${c.flag} ${c.name} to use this server.")
            .setPositiveButton("Import") { _, _ ->
                pendingImport = c
                importPicker.launch(arrayOf("*/*"))
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun requestConnect(c: Country) {
        val intent = VpnService.prepare(this)
        if (intent == null) {
            VpnController.connect(this, c)
        } else {
            pendingConnect = c
            vpnPermission.launch(intent)
        }
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun render(state: VpnState) {
        val active = state.status == Status.CONNECTING || state.status == Status.CONNECTED
        val shown = state.country?.takeIf { active } ?: selected
        b.selectedFlag.text = shown.flag
        b.selectedName.text = shown.name

        val (ringColor, status, label) = when (state.status) {
            Status.DISCONNECTED -> Triple(R.color.blue, "Disconnected", "CONNECT")
            Status.CONNECTING -> Triple(R.color.amber, "Connecting…", "CANCEL")
            Status.CONNECTED -> Triple(R.color.green, "Connected", "DISCONNECT")
            Status.ERROR -> Triple(R.color.red, "Connection failed", "CONNECT")
        }
        val color = ContextCompat.getColor(this, ringColor)
        b.connectButton.background = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(ColorUtils.setAlphaComponent(color, 70))
            setStroke(dp(5), color)
        }
        b.statusText.text = status
        b.connectLabel.text = label

        if (state.status == Status.ERROR && state.error != null) {
            b.detailText.text = state.error
            b.detailText.visibility = View.VISIBLE
        } else {
            b.detailText.visibility = View.GONE
        }

        b.reconnectButton.visibility =
            if (state.status == Status.CONNECTED || state.status == Status.ERROR) View.VISIBLE else View.GONE

        updateTimer(state)

        adapter.submit(
            Countries.all.map { c ->
                val act = active && state.country?.code == c.code
                ServerRow(
                    country = c,
                    configured = store.has(c.code),
                    active = act,
                    connecting = act && state.status == Status.CONNECTING,
                    selected = c.code == selected.code
                )
            }
        )
    }

    private fun updateTimer(state: VpnState) {
        if (state.status == Status.CONNECTED) {
            val s = (System.currentTimeMillis() - state.connectedAt) / 1000
            b.timerText.text = String.format("%02d:%02d:%02d", s / 3600, (s % 3600) / 60, s % 60)
        } else {
            b.timerText.text = "00:00:00"
        }
    }
}
