package com.techvpn.app

data class Country(val code: String, val name: String, val flag: String)

/** To add a new country later, add one line here and import a .conf for it in Settings. */
object Countries {
    val all: List<Country> = listOf(
        Country("US", "USA", "🇺🇸"),
        Country("GB", "United Kingdom", "🇬🇧"),
        Country("DE", "Germany", "🇩🇪"),
        Country("SG", "Singapore", "🇸🇬"),
        Country("NL", "Netherlands", "🇳🇱"),
        Country("CA", "Canada", "🇨🇦"),
        Country("JP", "Japan", "🇯🇵"),
        Country("IN", "India", "🇮🇳"),
    )

    fun byCode(code: String?): Country? = all.firstOrNull { it.code == code }
}
