package com.techvpn.app

import android.content.Context
import com.wireguard.android.backend.BackendException
import com.wireguard.android.backend.GoBackend
import com.wireguard.android.backend.Tunnel
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancelAndJoin
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.net.InetAddress

enum class Status { DISCONNECTED, CONNECTING, CONNECTED, ERROR }

data class VpnState(
    val status: Status = Status.DISCONNECTED,
    val country: Country? = null,
    val connectedAt: Long = 0L,
    val error: String? = null
)

/**
 * Drives the official WireGuard GoBackend. "CONNECTED" is only reported after
 * the WireGuard handshake with the server has actually completed.
 */
object VpnController {

    private const val HANDSHAKE_TIMEOUT_MS = 20_000L

    private val _state = MutableStateFlow(VpnState())
    val state: StateFlow<VpnState> = _state

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private var job: Job? = null
    private var backend: GoBackend? = null

    private val tunnel = object : Tunnel {
        override fun getName(): String = "techvpn"

        override fun onStateChange(newState: Tunnel.State) {
            // Tunnel torn down by the system (e.g. another VPN took over / user revoked it).
            if (newState == Tunnel.State.DOWN && _state.value.status == Status.CONNECTED) {
                _state.value = VpnState(
                    Status.ERROR,
                    _state.value.country,
                    error = "The VPN was stopped by the system."
                )
            }
        }
    }

    private fun backend(context: Context): GoBackend =
        backend ?: GoBackend(context.applicationContext).also { backend = it }

    fun reportError(country: Country?, message: String) {
        _state.value = VpnState(Status.ERROR, country, error = message)
    }

    fun connect(context: Context, country: Country) {
        val app = context.applicationContext
        if (_state.value.status == Status.CONNECTING) return // prevent duplicate connections

        val configText = ServerStore.get(app).configFor(country.code)
        if (configText == null) {
            reportError(country, "Server configuration required")
            return
        }

        _state.value = VpnState(Status.CONNECTING, country)
        val previous = job
        job = scope.launch {
            previous?.cancelAndJoin()
            try {
                val b = backend(app)
                if (b.runningTunnelNames.isNotEmpty()) {
                    b.setState(tunnel, Tunnel.State.DOWN, null)
                }
                val config = Config.parse(configText.byteInputStream())
                b.setState(tunnel, Tunnel.State.UP, config)

                if (!awaitHandshake(b)) {
                    runCatching { b.setState(tunnel, Tunnel.State.DOWN, null) }
                    reportError(
                        country,
                        "Could not reach the server (no handshake). Check the endpoint, keys and your internet connection."
                    )
                    return@launch
                }
                _state.value = VpnState(Status.CONNECTED, country, System.currentTimeMillis())
            } catch (e: CancellationException) {
                withContext(NonCancellable) {
                    runCatching { backend(app).setState(tunnel, Tunnel.State.DOWN, null) }
                }
                throw e
            } catch (e: BadConfigException) {
                reportError(country, "Invalid configuration: ${e.message ?: "unrecognised format"}")
            } catch (e: BackendException) {
                reportError(country, "VPN error: ${e.reason}")
            } catch (e: Exception) {
                reportError(country, e.message ?: "Unknown error")
            }
        }
    }

    fun disconnect(context: Context) {
        val app = context.applicationContext
        val previous = job
        _state.value = VpnState()
        job = scope.launch {
            previous?.cancelAndJoin()
            runCatching { backend(app).setState(tunnel, Tunnel.State.DOWN, null) }
        }
    }

    /** Waits until WireGuard reports a completed handshake with at least one peer. */
    private suspend fun awaitHandshake(b: GoBackend): Boolean {
        // A WireGuard handshake only starts when traffic is sent, so generate a
        // harmless DNS lookup through the tunnel while waiting.
        val kick = scope.launch {
            while (isActive) {
                runCatching { InetAddress.getByName("example.com") }
                delay(2_000)
            }
        }
        try {
            val deadline = System.currentTimeMillis() + HANDSHAKE_TIMEOUT_MS
            while (System.currentTimeMillis() < deadline) {
                val stats = b.getStatistics(tunnel)
                val done = stats.peers().any { key ->
                    (stats.peer(key)?.latestHandshakeEpochMillis() ?: 0L) > 0L
                }
                if (done) return true
                delay(500)
            }
            return false
        } finally {
            kick.cancel()
        }
    }
}
