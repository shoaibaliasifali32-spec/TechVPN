package com.techvpn.app

import android.content.Context
import android.content.SharedPreferences
import androidx.security.crypto.EncryptedSharedPreferences
import androidx.security.crypto.MasterKey

/**
 * Stores imported WireGuard configurations (which contain private keys)
 * encrypted with a key held in the Android Keystore.
 */
class ServerStore private constructor(context: Context) {

    private val prefs: SharedPreferences = EncryptedSharedPreferences.create(
        context,
        "techvpn_secure_store",
        MasterKey.Builder(context).setKeyScheme(MasterKey.KeyScheme.AES256_GCM).build(),
        EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
        EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
    )

    fun configFor(code: String): String? = prefs.getString("cfg_$code", null)

    fun has(code: String): Boolean = prefs.contains("cfg_$code")

    fun save(code: String, configText: String) {
        prefs.edit().putString("cfg_$code", configText).apply()
    }

    fun remove(code: String) {
        prefs.edit().remove("cfg_$code").apply()
    }

    fun selectedCode(): String? = prefs.getString("selected", null)

    fun setSelected(code: String) {
        prefs.edit().putString("selected", code).apply()
    }

    companion object {
        @Volatile
        private var instance: ServerStore? = null

        fun get(context: Context): ServerStore =
            instance ?: synchronized(this) {
                instance ?: ServerStore(context.applicationContext).also { instance = it }
            }
    }
}
