package com.techvpn.app

import android.content.Context
import android.net.Uri
import com.wireguard.config.BadConfigException
import com.wireguard.config.Config

object ConfigImport {
    /** Validates a WireGuard .conf with the official parser and saves it. Returns null on success, or an error message. */
    fun import(context: Context, uri: Uri, country: Country): String? {
        return try {
            val text = context.contentResolver.openInputStream(uri)?.use { stream ->
                stream.bufferedReader().readText()
            } ?: return "Could not open the selected file."
            if (text.length > 65536) return "That file is too large to be a WireGuard configuration."
            Config.parse(text.byteInputStream())
            ServerStore.get(context).save(country.code, text)
            null
        } catch (e: BadConfigException) {
            "Invalid WireGuard configuration: ${e.message ?: "unrecognised format"}"
        } catch (e: Exception) {
            "Could not read the file: ${e.message ?: "unknown error"}"
        }
    }
}
