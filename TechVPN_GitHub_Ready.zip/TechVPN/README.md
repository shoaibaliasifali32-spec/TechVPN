# Tech VPN

Android WireGuard VPN client built with Kotlin and the official WireGuard Android tunnel library.

## Import your own WireGuard server configuration

1. Install the APK on your Android phone.
2. Open Tech VPN and select a country, or open **Settings**.
3. Tap **Import** beside that country and choose your provider/server `.conf` file.
4. Return to the home screen, select that country, and tap **Connect**.
5. Approve Android's VPN permission prompt.

The app validates the file with WireGuard's config parser and stores the configuration encrypted on the device using Android Keystore-backed encrypted preferences. Each country can have its own configuration; use **Replace** to change it.

**Important:** A country label by itself is not a VPN server. You must obtain a real, working WireGuard `.conf` file from a VPN provider or from a WireGuard server you operate. The configuration contains a private key: do not commit or upload `.conf` files to GitHub, and do not share them publicly. This repository intentionally contains no server credentials.

The app reports **Connected** only after a WireGuard peer handshake is detected. A successful APK build does not guarantee that a server configuration is valid, reachable, or subscribed/authorized.

## Build on GitHub

1. Create a GitHub repository named `TechVPN`.
2. Upload the contents of this project (the files inside the `TechVPN` folder, not the enclosing folder).
3. Commit the files to `main` or `master`.
4. Open the repository's **Actions** tab and run **Build Debug APK** (or let the push trigger it).
5. Open the completed workflow run and download the `TechVPN-debug-apk` artifact.
6. Extract the artifact ZIP to get the APK.

## Local build

Requires JDK 17, Android SDK, and Gradle 8.9:

```bash
gradle --no-daemon assembleDebug
```

APK output: `app/build/outputs/apk/debug/app-debug.apk`.
