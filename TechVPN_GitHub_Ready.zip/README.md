# Tech VPN

Android WireGuard VPN client (Kotlin, official `com.wireguard.android:tunnel` library, minSdk 26).
Import your own WireGuard `.conf` files per country; the app shows "Connected" only after a real WireGuard handshake.

Build locally: `gradle assembleDebug` (Gradle 8.9+, JDK 17) or open in Android Studio.
Build on GitHub: push to `main`, then Actions > "Build Debug APK" > download artifact `TechVPN-debug-apk`.
